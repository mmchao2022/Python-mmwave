"""
    ofdm_frame
    =====================

    frame structure:
        --------------------------------------------------------
        | short training  | pilot  |  payload  |
        --------------------------------------------------------
    provides:
    1. construct ofdm symbol frame 
"""

import numpy as np 
from numpy.fft import fft,ifft,fftshift 
import matplotlib.pyplot as pl
from  mod_demod import modulate,demodulate
import filter





num_tones=64 ## FFT size: 64 subcarriers
num_data_tones=60
cp_len=16
indexes_null_tones=np.array([-32,-31,0,31])+32   #null_tones +index offset
indexes_data_tones=np.append(np.arange(-30,0),np.arange(1,31))+32  #data_tones +index offset

st_symbols=np.array([1+1j,-1-1j,1+1j,-1-1j,-1+1j,1+1j,-1-1j,-1-1j,1+1j,1+1j,1+1j,1+1j])*np.sqrt(13/6) #short training symbols
st_symbols_upsampling=np.zeros(num_data_tones,np.complex64)
for i in range(st_symbols.size//2):
    st_symbols_upsampling[6+i*4]=st_symbols[i]
for i in range(st_symbols.size//2,st_symbols.size):
    st_symbols_upsampling[9+i*4]=st_symbols[i]


zadoff=np.exp(1j*np.pi*np.power(np.arange(0,num_data_tones),2)/num_data_tones) # zad off sequence



class ofdm_frame:
    def __init__(self,bin_payload:np.array,order=4):
        self.train_seq=data_to_cp_ofdm(st_symbols_upsampling,2)
        self.pilot_seq=data_to_cp_ofdm(zadoff)
        self.payload = ofdm_modulate(modulate(bin_payload,order))

    def frame_to_buffer(self):
        padlen=16
        padding=np.full(padlen,0.1+0.1j,dtype=np.complex64)
        padzeros=np.zeros(150,dtype=np.complex64)
        ofdm_symbol=np.concatenate((self.train_seq,self.pilot_seq,self.payload))
        ofdm_symbol=ofdm_symbol/np.max(np.absolute(ofdm_symbol))
        frame_symbol=np.concatenate((padzeros,padding,ofdm_symbol,padding,padzeros,padzeros,padzeros,padzeros))
        buffer=filter.pulse_shaping(frame_symbol,2,0.25,6)
        
        sym_energy=np.max(np.absolute(buffer))
        buffer=buffer/sym_energy/1.5
        buffer=buffer[:364*6]
        print(buffer.size)
        buffer=buffer.reshape(1,-1)
        return buffer
def data_to_cp_ofdm(data,rpt_num=1):
    fft_data=np.zeros(64,dtype=np.complex64)
    fft_data[indexes_data_tones]=data 
    ofdm_symbol=ifft(fftshift(fft_data))
    cp_ofdm_data=np.append(ofdm_symbol[num_tones-cp_len:],ofdm_symbol)
    if rpt_num ==1:
        return cp_ofdm_data
    else:
        return np.tile(cp_ofdm_data,rpt_num)

def ofdm_modulate(symbols:np.array):
    assert symbols.size %num_data_tones ==0, "modulated symbols size is not multiple times of 64"
    
    s2p_symbols=np.reshape(symbols,(symbols.size//num_data_tones,num_data_tones))  # 2 dimentional array, one row vector represent 60 data carrier symbols
    
    s2p_cp_ofdm_symbols=np.zeros((symbols.size//num_data_tones,num_tones+cp_len),dtype=np.complex64)
    
    for i in np.arange(0,symbols.size//num_data_tones):
        s2p_cp_ofdm_symbols[i]=data_to_cp_ofdm(s2p_symbols[i])
    
    return s2p_cp_ofdm_symbols.reshape(1,-1)[0]  #parallel to serial

f=ofdm_frame(np.random.choice([1,0],960),order=4)
tx_frame=f.frame_to_buffer()[0]

pl.plot(tx_frame.real)
pl.plot(tx_frame.imag)
tx_frame.tofile('ofdm_4qam.dat')
pl.show()


