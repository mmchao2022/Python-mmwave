'''
Description: 
Author: Yu Chao 
Date: 2022-04-16 11:39:08
LastEditTime: 2022-04-16 11:40:15
'''
import numpy as np
from filter import matched_filter
from numpy.fft import fft,ifft,fftshift


def channel_est(buf):
    # num_tones=64 ## FFT size: 64 subcarriers
    num_data_tones=60
    # cp_len=16
    # indexes_null_tones=np.array([-32,-31,0,31])+32   #null_tones +index offset
    indexes_data_tones=np.append(np.arange(-30,0),np.arange(1,31))+32  #data_tones +index offset
    zadoff=np.exp(1j*np.pi*np.power(np.arange(0,num_data_tones),2)/num_data_tones) # zad off sequence
    sps = 2
    rc = 0.25
    sl = 6
    fs=10e6
    buf = matched_filter(buf,sps,rc,sl)
    sym_off=np.argmax([np.mean(np.power(np.absolute(buf[i::2]),2)) for i in range(0,2)])
    sync_symbols=buf[sym_off::2]

    ################# frame sync  ##############################
    bl=1200
    N=64
    W=80
    bt=16
    sc=np.empty(bl)
    for i in range(0,bl):
        p=np.conjugate(sync_symbols[i:i+N])
        n=sync_symbols[i+W:i+W+N]
        R=np.dot(p,n)
        # PD=np.power(np.dot(np.conjugate(n),n),2)
        # sc[i]=np.power(np.absolute(R/PD),2)
        sc[i]=np.power(np.absolute(R),2)
    sc=sc/(np.max(sc)-np.min(sc))
    thr = 0.6
    f_sync_idx=np.argwhere(sc>thr)[0][0]
    # print('frame start: {}\n'.format(f_sync_idx))
    sync_symbols=sync_symbols[f_sync_idx:]


    ####################### Freq est ################################
    x=sync_symbols[bt*3:bt*3+W]
    y=sync_symbols[bt*5:bt*5+W]

    und=np.dot(x.conjugate(),y)/(np.dot(x.conjugate(),x))
    f=-np.angle(und)*fs/(2*2*16*1*np.pi*2)
    # print('freq est:{}'.format(f))
    cp_ofdm_symbols=sync_symbols*np.exp(2j*np.pi*f/fs*2*np.arange(0,len(sync_symbols)))

    ####################### Del cp ##################################
    i=cp_ofdm_symbols.size//80
    cp_ofdm_symbols=cp_ofdm_symbols[:i*80]
    s2p_cp_ofdm_symbols=cp_ofdm_symbols.reshape(i,80)
    s2p_ofdm_symbols=s2p_cp_ofdm_symbols[:,16:]

    ##################### channel estimation ###########################
    recv_pilot=fftshift(fft(s2p_ofdm_symbols[2]))[indexes_data_tones]
    chest=recv_pilot/zadoff
    return chest