import numpy as np
import matplotlib.pyplot as pl
from numpy.fft import fft,ifft,fftshift
from filter import matched_filter

num_tones=64 ## FFT size: 64 subcarriers
num_data_tones=60
cp_len=16
indexes_null_tones=np.array([-32,-31,0,31])+32   #null_tones +index offset
indexes_data_tones=np.append(np.arange(-30,0),np.arange(1,31))+32  #data_tones +index offset

zadoff=np.exp(1j*np.pi*np.power(np.arange(0,num_data_tones),2)/num_data_tones) # zad off sequence


fname="/home/yuc/passive mmwave/eder_evk/RX/data_220110/push2.dat"
# fname = "ofdm.dat"
sps = 2
rc = 0.25
sl = 6
fs=10e6
data_count = 2184
data_complex=np.fromfile(fname,dtype=np.complex64,count=-1)
print('data size:',data_complex.shape)
data_sample = data_complex.reshape(-1,2,order = "F")
data_sample = np.transpose(data_sample)
data_tar = data_sample[0,:data_count*2].reshape(-1)
data_ref = data_sample[1,:data_count*2].reshape(-1)
pl.figure(1,figsize=(15,10))
pl.subplot(2,1,1)
pl.plot(data_ref.real)
pl.title('ref')
pl.subplot(2,1,2)
pl.plot(data_tar.real)
pl.title('target')


buf = data_ref
# buf = data_complex
buf = matched_filter(buf,sps,rc,sl)






sym_off=np.argmax([np.mean(np.power(np.absolute(buf[i::2]),2)) for i in range(0,2)])
print("sym_off:",sym_off)
sync_symbols=buf[sym_off::2]
data_time = sync_symbols.copy()
# sync_symbols = sync_symbols[200:]
print("sync_size:{}".format(sync_symbols.size))
# sync_symbols = sync_symbols[1000:]

# # frame sync 
bl=1200
N=64
W=80
bt=16
sc=np.empty(bl)
for i in range(0,bl):
    p=np.conjugate(sync_symbols[i:i+N])
    n=sync_symbols[i+W:i+W+N]
    R=np.dot(p,n)
    # PD=np.power(np.dot(np.conjugate(n),n),2)
    # sc[i]=np.power(np.absolute(R/PD),2)
    sc[i]=np.power(np.absolute(R),2)


sc=sc/(np.max(sc)-np.min(sc))
thr = 0.6
# thr = np.max(sc) * 0.75


f_sync_idx=np.argwhere(sc>thr)[0][0]

print('frame start: {}\n'.format(f_sync_idx))


sync_symbols=sync_symbols[f_sync_idx:]



x=sync_symbols[bt*3:bt*3+W]
y=sync_symbols[bt*5:bt*5+W]

und=np.dot(x.conjugate(),y)/(np.dot(x.conjugate(),x))
f=-np.angle(und)*fs/(2*2*16*1*np.pi*2)

print('freq est:{}'.format(f))

cp_ofdm_symbols=sync_symbols*np.exp(2j*np.pi*f/fs*2*np.arange(0,len(sync_symbols)))


# print(cp_ofdm_symbols.size)
i=cp_ofdm_symbols.size//80
cp_ofdm_symbols=cp_ofdm_symbols[:i*80]
s2p_cp_ofdm_symbols=cp_ofdm_symbols.reshape(i,80)
s2p_ofdm_symbols=s2p_cp_ofdm_symbols[:,16:]
## channel estimation
recv_pilot=fftshift(fft(s2p_ofdm_symbols[2]))[indexes_data_tones]
chest=recv_pilot/zadoff
print(chest.size)

recv_sym = fftshift(fft(s2p_ofdm_symbols[3]))[indexes_data_tones]
recv_sym_eqa=recv_sym/chest

pl.figure(2,figsize=(15,10))
ax=pl.subplot(221)

ax.plot(data_time.real)
ax.plot(data_time.imag)
ax.set_title('ofdm signal:'+str(int(fs/1e6))+'MHz')
ay=pl.subplot(222)
ay.plot(sc)
ay.set_title('frame sync')
az=pl.subplot(223)
az.plot(np.absolute(chest))
az.set_title('CSI')
az.set_ylim(0)
av=pl.subplot(224)
av.plot(recv_sym_eqa.real,recv_sym_eqa.imag,linestyle='None',marker='.')
av.set_title('constellation')





pl.show()




