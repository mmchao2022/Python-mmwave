import numpy as np
import matplotlib.pyplot as pl 
from scipy import signal


def rrc(sps,rc,sl):
    """root raised cosine filter

    Args:
        sps: samples per symbol(how many samples to represent a symbol)
        rc : roll off coefficient(roll off factor)
        sl : filter length(it means how many symbols the filter will expand)
    Returns:
        f: filter samples
    """

    ## this ensures the denomiator of rrc formalar is not 0.
    if int(rc*4*sps*sl*125)%2==0:
        rc=rc-0.000001
        
        
    idx=np.linspace(-sl/2.0,sl/2.0,sps*sl+1,dtype=np.float32)
    ## apply rrc formula.
    f= ((np.cos((1+rc)*np.pi*idx)*4*rc/np.pi)+((np.sinc((1-rc)*idx))*(1-rc)))/((1-(4*rc*idx)**2)*np.sqrt(sps))
    return f

def pulse_shaping(modsymbols,sps,rc,sl):
    """pulse_shaping
            input   : modulated symbols, here we call symbols.
            output  : sample stream, we call it baseband signal.

    Args:
        modsymbols: modulated symbols.bpsk,qam or other symbols.

        sps,rc,sl : root raised cosine parameter.
        
    Returns:
        sig: baseband signal.
    """
    ## upsampling by insert zeros.
    ns=np.zeros(sps*modsymbols.size,dtype=np.complex64)
    ns[::sps]=modsymbols[:]
    f=rrc(sps,rc,sl)
    
    ## generate baseband signal by convolution upsampled symbols with pulse shaping filter.
    sig=np.convolve(ns,f)
    
    return sig

def matched_filter(recvsamples,sps,rc,sl):
    """matched filter
           which increases SNR.
    Args:
        recvsamples: raw received baseband signal.

        sps,rc,sl : root raised cosine parameter.
        
    Returns:
        f: filter samples
    """
    f=rrc(sps,rc,sl)
    # convolution raw received signals with pulse shaping filter.
    sig=np.convolve(recvsamples,f)
    return sig


